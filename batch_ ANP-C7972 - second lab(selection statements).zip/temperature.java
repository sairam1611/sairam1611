package firstproject;

public class Temperature {

	public static void main(String[] args) {
	    double fahrenheit=98.6;
	    double celcius=fahrenheit-32*5/9;
	    System.out.println("The temperature in fahrenheit is:" + fahrenheit);
	    System.out.println("The temperature in celcius is:"+celcius);

	}

}
