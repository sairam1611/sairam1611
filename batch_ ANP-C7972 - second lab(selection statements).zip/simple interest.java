package firstproject;

public class Simple {

	public static void main(String[] args) {
	double principal = 1000;
	double rate = 2;
	double time = 3;
	double interest =(principal*rate*time)/100;
	System.out.println("The principal amount:"+ principal);
	System.out.println("The rate of interest:"+rate+"%");
	System.out.println("The time period:"+time+"years");
	System.out.println("The simple Interest:"+interest);
	

	}

}
