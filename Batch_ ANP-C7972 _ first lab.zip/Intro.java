package newproject;

public class Intro 
{

	public static void main(String[] args)
	{
       System.out.println("Hello This is Jaya chandra");
       System.out.println("I am from bhadradri kothagudem District");
       System.out.println("currently i am pursuing MCA");
       System.out.println("i completed my degree in 2023");
       System.out.println("with 76%");
       System.out.println("I completed my inter in 2020");
       System.out.println("with 75.7%");
       System.out.println("I completed my 10th in 2018");
       System.out.println("We are 4 members");
       System.out.println("my father name is bagam venkateshwarlu");
       System.out.println("he works as cashier in khammam");
       
	}

}
