package newproject;

public class Pc 
{

	public static void main(String[] args) 
	{
		System.out.println("Computers are essential modern tools.");
		System.out.println("CPUs act as computer brains.");
		System.out.println("Internet connects global users.");
		System.out.println("Computers revolutionize various industries.");
		System.out.println("Quantum computers solve complex problems.");
		System.out.println("PCs made computing widely accessible.");
		System.out.println("Operating systems manage computer resources.");
		System.out.println("Smartphones are handheld computers.");
		System.out.println("AI enables human-like computer tasks.");
		System.out.println("Computer science constantly evolves.");
       
	}

}
